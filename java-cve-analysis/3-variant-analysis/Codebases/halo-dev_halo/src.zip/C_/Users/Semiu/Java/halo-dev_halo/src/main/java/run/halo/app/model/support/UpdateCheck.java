package run.halo.app.model.support;

/**
 * Update check for hibernate validation
 *
 * @author johnniang
 * @date 19-4-28
 */
public interface UpdateCheck {
}
