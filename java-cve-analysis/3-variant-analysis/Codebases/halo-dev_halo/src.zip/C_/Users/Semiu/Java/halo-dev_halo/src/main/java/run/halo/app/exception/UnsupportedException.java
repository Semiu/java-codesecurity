package run.halo.app.exception;

/**
 * @author ZhiXiang Yuan
 * @date 2021/01/18 20:13
 */
public class UnsupportedException extends ServiceException {
    public UnsupportedException(String message) {
        super(message);
    }
}
