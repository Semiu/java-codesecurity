/**
 * Support package for the Java 6 ServiceLoader facility.
 */
@NonNullApi
@NonNullFields
package org.springframework.beans.factory.serviceloader;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
