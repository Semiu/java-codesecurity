package jadx.core.dex.visitors.typeinference;

public enum BoundEnum {
	ASSIGN,
	USE
}
